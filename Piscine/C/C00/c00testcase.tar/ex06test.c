#include "ex06/ft_print_comb2.c"

int main()
{
	ft_print_comb2();
}
