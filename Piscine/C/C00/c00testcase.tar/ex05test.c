#include "ex05/ft_print_comb.c"

int main()
{
	ft_print_comb();
}
