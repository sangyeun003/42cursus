#include <stdio.h>
#include <unistd.h>
#include "ex00/ft_putchar.c"
#include "ex01/ft_print_alphabet.c"
#include "ex02/ft_print_reverse_alphabet.c"
#include "ex03/ft_print_numbers.c"
#include "ex04/ft_is_negative.c"
#include "ex07/ft_putnbr.c"


void ex00()
{
	printf("============	ex00	============\n\n");

	ft_putchar('h');
	ft_putchar('e');
	ft_putchar('l');
	ft_putchar('l');
	ft_putchar('o');
	ft_putchar('!');
	ft_putchar('\n');

	printf("hello! 가 나오면 정답");

	printf("\n\n====================================\n\n");
}

void ex01()
{
	printf("============	ex01	============\n\n");

	ft_print_alphabet();
	printf("\nabcdefghijklmnopqrstuvwxyz 가 나오면 정답");

	printf("\n\n====================================\n\n");
}

void ex02()
{
	printf("============	ex02	============\n\n");
	
	ft_print_reverse_alphabet();
	printf("\nzyxwvutsrqponmlkjihgfedcba 가 나오면 정답");

	printf("\n\n====================================\n\n");
}

void ex03()
{
	printf("============	ex03	============\n\n");

	ft_print_numbers();	
	printf("\n0123456789 가 나오면 정답");

	printf("\n\n====================================\n\n");
}

void ex04()
{
	printf("============	ex04	============\n\n");

	ft_is_negative(-1);
	ft_is_negative(0);
	ft_is_negative(1);
	printf("\nNPP 가 나오면 정답");

	printf("\n\n====================================\n\n");
}

void ex05ex06()
{
	printf("============	ex05	============\n\n");

	printf("diff 파일 참고");

	printf("\n\n====================================\n\n");
	printf("============	ex06	============\n\n");

	printf("diff 파일 참고");

	printf("\n\n====================================\n\n");

}

void ex07()
{
	printf("============	ex07	============\n\n");

	ft_putnbr(-2147483648);
	printf("\n");
	ft_putnbr(2147483647);
	printf("\n");
	ft_putnbr(0);
	printf("\n");
	printf("-2147483648\n2147483647\n0 \n이나오면 정답");
	printf("\n\n====================================\n\n");
}


int main()
{
	ex00();
	ex01();
	ex02();
	ex03();
	ex04();
	ex05ex06();
	ex07();
}
