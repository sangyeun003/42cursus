#!/bin/bash
cc -Wall -Wextra -Werror c00testcase.c -o testcase.out
./testcase.out
if [ -e "./ex05/ft_print_comb.c" ];
then
	echo "diff ex05result ex05answer:"
	cc -Wall -Wextra -Werror ex05test.c -o ex05.out
	./ex05.out > ex05result
	diff ex05result ex05answer
	rm ./ex05.out ex05result
fi
if [ -e "./ex06/ft_print_comb2.c" ];
then
	echo "diff ex06result ex06answer:"
	cc -Wall -Wextra -Werror ex06test.c -o ex06.out
	./ex06.out > ex06result
	diff ex06result ex06answer
	rm ./ex06.out ex06result
fi
if [ -e "./ex08/ft_print_combn.c" ];
then
	echo "diff ex08result ex08answer:"
	cc -Wall -Wextra -Werror ex08test.c -o ex08.out
	./ex08.out > ex08result
	diff ex08result ex08answer
	rm ./ex08.out ex08result
fi

echo "if nothing shows after diff, you got the anser"
echo "!! comb 문제들에서 줄바꿈을 하셨다면 오답으로 표시될 수 있으니 안심하시길 바랍니다 !!"
rm testcase.out ex05test.c ex06test.c ex08test.c c00testcase.c
rm ex05answer ex06answer ex08answer
exit 0
