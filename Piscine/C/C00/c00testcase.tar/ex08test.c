#include <stdio.h>
#include <unistd.h>
#include "ex08/ft_print_combn.c"

int main()
{
	for (int i=2; i <= 9; i++)
	{
		ft_print_combn(i);
	}
}
